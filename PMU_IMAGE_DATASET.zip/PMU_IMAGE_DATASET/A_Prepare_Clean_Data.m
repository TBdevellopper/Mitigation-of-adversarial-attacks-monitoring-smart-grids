% These codes are designed to prepare the row dataset which dosn't contain and
% adverserial attacks.
% Original dataset files are located in follwing folder respectively
% "DB_FLT","DB_GNL", and "DB_SMS".
% prepared data will be stored in "Prepared_data" folder as "image_data.mat".
% The original paper of the dataset is:
%
% Biswal, Milan, Satyajayant Misra, and Abu S. Tayeen.
% "Black box attack on machine learning assisted wide area monitoring and protection systems."
% 2020 IEEE Power & Energy Society Innovative Smart Grid Technologies Conference (ISGT). IEEE, 2020.
%
%
%
% The current codes are from this paper (Please cite our work):
%
% Berghout, T.; Benbouzid, M.; Amirat, Y. 
% Towards Resilient and Secure Smart Grids against PMU Adversarial Attacks:
% A Deep Learning-Based Robust Data Engineering Approach. 
% Electronics 2023, 12, 2554. https://doi.org/10.3390/electronics12122554

%% Note: Please read our paper carefully to be able undrstand data processing methodology
clear
clc
addpath('Data_processing_codes')% 
%% 1) DB_FLT
foldername=('DB_FLT');
listing = dir([foldername '\\*.jpg']);
[X,Y]=ImageProcess(foldername,listing);
[X1,Y1]=ExtrauctFeatures(X,Y);
clearvars -except X1 Y1 
%% 2) DB_GNL
foldername=('DB_GNL');
listing = dir([foldername '\\*.jpg']);
[X,Y]=ImageProcess(foldername,listing);
[X2,Y2]=ExtrauctFeatures(X,Y);
clearvars -except X1 Y1 X2 Y2
%% 3) DB_SMS
foldername=('DB_SMS');
listing = dir([foldername '\\*.jpg']);
[X,Y]=ImageProcess(foldername,listing);
[X3,Y3]=ExtrauctFeatures(X,Y);
clearvars -except X1 Y1 X2 Y2 X3 Y3
%% 4) Orgenize data
X=[X1; X2; X3];
Y=[Y1; Y2; Y3];
clearvars -except X Y
%% 5) SMOTE: Synthetic Minority Over-sampling Technique 
[X,Y]= SMOTE(X,Y); % SMOTE
%% 6) Sellection based on data vesualization
% 1 and 5,7,9 are the best; [mean peak2peak CrestFactor ImpulseFactor];
% X=X(:,[1 5 7 9]);
%% 6) Save data
clearvars -except X Y
save('Prepared_data\\image_data.mat')
