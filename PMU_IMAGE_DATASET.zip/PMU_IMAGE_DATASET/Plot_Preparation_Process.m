clear all
clc
addpath('Data_processing_codes','Prepared_data')
%% 1) Step one (Image processing)
i=5;
foldername='DB_FLT';
listing = dir([foldername '\\*.jpg']);
filename=[foldername '\\' listing(i).name];
%
figure(1)
%% 1) Upload data
data=imread(filename);
%
subplot(1,4,1)
imagesc(data);
xlabel('(a)')
%
data=data(:,:,1);
%% 1) Denoising
net    = denoisingNetwork('DnCNN');
X_temp = denoiseImage(data,net);
%
subplot(1,4,2)
imagesc(X_temp);
xlabel('(b)')
%
%% 2) Segmentation based clustering (This technique lets you create a segmented labeled image using a specific clustering algorithm. Using K-means clustering�based segmentation, imsegkmeans segments an image into K number of clusters.)
[L,~]  = imsegkmeans(X_temp,2);
 X_temp = labeloverlay(X_temp,L);
%
subplot(1,4,3);
imagesc(X_temp);
xlabel('(c)')
%% 3) Extruct image features (HOG)
[featureVector,hogVisualization] = extractHOGFeatures(X_temp);
%
subplot(1,4,4);
imagesc(X_temp);
hold on 
plot(hogVisualization);
hold off
xlabel('(d)')
%% Step two (Extruction)
figure(2)
% 1) plot features of HOG
subplot(1,4,1)
idx=scaledata(1:length(featureVector),0,1);
plot(idx,featureVector);
xlabel({'Relative frequency','(a)'});
ylabel('Amplitude');

%% 2) plot extraucted features
variables_names={'Mean','Standard deviation','Skewness','Kurtosis','Peak to Peak', 'Square root of the arithmetic mean', ...
                 'Crest factor',' Shape factor','Impulse factor',...
                 'Margin factor','Energy'};
% FLT
subplot(1,4,2)
load('image_data');
I=find(Y=='FLT');
plot(X(I,:));
%
xlabel({'Samples','(b)'});
ylabel('Features');
lgd=legend(variables_names);
lgd.EdgeColor='none';
lgd.Color='none';
%% 
% GNL
subplot(1,4,3)
load('image_data');
I=find(Y=='GNL');
plot(X(I,:));
%
xlabel({'Samples','(c)'});
ylabel('Features');
% lgd=legend(variables_names);
% lgd.EdgeColor='none';
% lgd.Color='none';
% xlim([0 210])
% SMS
subplot(1,4,4)
load('image_data');
I=find(Y=='SMS');
plot(X(I,:));
%
xlabel({'Samples','(d)'});
ylabel('Features');
% lgd=legend(variables_names);
% lgd.EdgeColor='none';
% lgd.Color='none';
% xlim([0 210])
%% 3) plot adverserial data example
% %figure(3)
% clc
% addpath('ADV_Data_codes')
% indexOfClass=1;
% [XAdv,Perturbation,OriginalClass,PredictedClass]=Gnerate_Adverserial_Examples(filename,indexOfClass);
