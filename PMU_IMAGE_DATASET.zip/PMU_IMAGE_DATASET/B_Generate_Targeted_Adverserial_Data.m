%
% These codes generates Targted adverserial examples from the original dataset
% using pretrained networks.
% this means that targeted labels are sellected by user and known.
% The process follows particularly fast gradient sign method (FGSM)
% improved with basic iterative method (BIM) in two following papers.
% 
%
% Goodfellow, Ian J., Jonathon Shlens, and Christian Szegedy. 
% “Explaining and Harnessing Adversarial Examples.” 
% Preprint, submitted March 20, 2015. https://arxiv.org/abs/1412.6572.
%
% Kurakin, Alexey, Ian Goodfellow, and Samy Bengio. 
% “Adversarial Examples in the Physical World.” 
% Preprint, submitted February 10, 2017. https://arxiv.org/abs/1607.02533.
%
% Generated data from these codes will be stored in following folders
% respectively, "DB_FLT_Targeted_ADV","DB_GNL_Targeted_ADV", and
% "DB_FLT_Targeted_ADV";
%
%
clear
clc
addpath('ADV_Data_codes');
%%
foldername=('DB_FLT');
listing = dir([foldername '\\*.jpg']);
indexOfClass=1;
for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
[XAdv,Perturbation]=Gnerate_Targeted_Adverserial_Examples(filename,indexOfClass);
filename=[foldername '_Targeted_ADV\\' 'ADV_' filename(9:end)];
imwrite(XAdv,filename)
end
%%
foldername=('DB_GNL');
listing = dir([foldername '\\*.jpg']);
indexOfClass=2;
for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
[XAdv,Perturbation]=Gnerate_Targeted_Adverserial_Examples(filename,indexOfClass);
filename=[foldername '_Targeted_ADV\\' 'ADV_' filename(9:end)];
imwrite(XAdv,filename)
end
%%
foldername=('DB_SMS');
listing = dir([foldername '\\*.jpg']);
indexOfClass=3;
for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
[XAdv,Perturbation]=Gnerate_Targeted_Adverserial_Examples(filename,indexOfClass);
filename=[foldername '_Targeted_ADV\\' 'ADV_' filename(9:end)];
imwrite(XAdv,filename)
end
