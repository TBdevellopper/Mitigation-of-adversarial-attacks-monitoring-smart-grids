function [XAdv,Perturbation]=Gnerate_Adverserial_Examples(filename,indexOfClass)
% This function is used to generate adverserial images for original images;
%% 1) load squeezenet
net    = squeezenet;
lgraph = layerGraph(net);
lgraph = removeLayers(lgraph,lgraph.Layers(end).Name);
dlnet  = dlnetwork(lgraph);
%% Extract the class labels.
classes = categories(net.Layers(end).Classes);
%% Load an image to use to generate an adversarial example. The image is a picture of a golden retriever.
img = imread(filename);
OriginalSize=size(img);
OriginalSize=OriginalSize(1:2);
T = convertCharsToStrings(classes{indexOfClass,1});
%% Resize the image to match the input size of the network.
inputSize = dlnet.Layers(1).InputSize;
img = imresize(img,inputSize(1:2));
X = dlarray(double(img),"SSCB");
%% Prepare the label by one-hot encoding it.
T = onehotencode(T,1,'ClassNames',classes);
T = dlarray(single(T),"CB");
%% Untargeted Fast Gradient Sign Method
gradient = dlfeval(@untargetedGradients,dlnet,X,T);
%% Set epsilon to 1 and generate the adversarial example.
epsilon = 1;
XAdv = X + epsilon*sign(gradient);
%PredictedClass=predict(dlnet,XAdv);
Perturbation=uint8(extractdata(XAdv-X+127.5));
Perturbation=imresize(Perturbation,'OutputSize',OriginalSize);
XAdv = uint8(extractdata(XAdv));
%OriginalClass=T;
XAdv = imresize(XAdv,'OutputSize',OriginalSize);
%

end

