function [XAdv,Perturbation]=Gnerate_Targeted_Adverserial_Examples(filename,indexOfClass)

% This function is used to generate adverserial images for original images;
%% 1) load squeezenet
net    = squeezenet;
lgraph = layerGraph(net);
lgraph = removeLayers(lgraph,lgraph.Layers(end).Name);
dlnet  = dlnetwork(lgraph);
%% Extract the class labels.
classes = categories(net.Layers(end).Classes);
%% Load an image to use to generate an adversarial example. The image is a picture of a golden retriever.
img = imread(filename);
OriginalSize=size(img);
OriginalSize=OriginalSize(1:2);
T = convertCharsToStrings(classes{indexOfClass,1});
%% Resize the image to match the input size of the network.
inputSize = dlnet.Layers(1).InputSize;
img = imresize(img,inputSize(1:2));
X = dlarray(double(img),"SSCB");
%% Prepare the label by one-hot encoding it.
T = "great white shark";
T = onehotencode(T,1,'ClassNames',classes);
% T = onehotencode(T,1,'ClassNames',classes);
% T = dlarray(single(T),"CB");
%% Untargeted Fast Gradient Sign Method
epsilon = 5;
alpha = 0.2;
numIterations = 25;
% Keep track of the perturbation and clip any values that exceed epsilon.
delta = zeros(size(X),'like',X);
for i = 1:numIterations
    gradient = dlfeval(@targetedGradients,dlnet,X+delta,T);
    
    delta = delta - alpha*sign(gradient);
    delta(delta >  epsilon)  =  epsilon;
    delta(delta < -epsilon) = -epsilon;
end


%% Set epsilon to 1 and generate the adversarial example.
XAdv= X + delta;
Perturbation=uint8(extractdata(XAdv-X+127.5));
Perturbation=imresize(Perturbation,'OutputSize',OriginalSize);
XAdv = uint8(extractdata(XAdv));
XAdv = imresize(XAdv,'OutputSize',OriginalSize);
end

