% These codes generates Untargted adverserial examples from the original dataset
% using pretrained networks.
% this means that targeted labels are sellected "randomly".
% The process follows particularly fast gradient sign method (FGSM)
% in this following papers.
% 
%
% Goodfellow, Ian J., Jonathon Shlens, and Christian Szegedy. 
% “Explaining and Harnessing Adversarial Examples.” 
% Preprint, submitted March 20, 2015. https://arxiv.org/abs/1412.6572.
%
%
%  Generated data from these codes will be stored in following folders
%  respectively, "DB_FLT_ADV","DB_GNL_ADV", and
% "DB_FLT_ADV";
%
%
clear
clc
addpath('ADV_Data_codes');
%%
foldername=('DB_FLT');
listing = dir([foldername '\\*.jpg']);
indexOfClass=1;
for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
[XAdv,Perturbation]=Gnerate_Adverserial_Examples(filename,indexOfClass);
filename=[foldername '_ADV\\' 'ADV_' filename(9:end)];
imwrite(XAdv,filename)
end
%%
foldername=('DB_GNL');
listing = dir([foldername '\\*.jpg']);
indexOfClass=2;
for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
[XAdv,Perturbation]=Gnerate_Adverserial_Examples(filename,indexOfClass);
filename=[foldername '_ADV\\' 'ADV_' filename(9:end)];
imwrite(XAdv,filename)
end
%%
foldername=('DB_SMS');
listing = dir([foldername '\\*.jpg']);
indexOfClass=3;
for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
[XAdv,Perturbation]=Gnerate_Adverserial_Examples(filename,indexOfClass);
filename=[foldername '_ADV\\' 'ADV_' filename(9:end)];
imwrite(XAdv,filename)
end
