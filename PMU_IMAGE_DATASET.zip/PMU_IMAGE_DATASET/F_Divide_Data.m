% These codes will divide dataset to training and testing sets which will be stored in
% "Prepared_data" folder as "Divided_data.mat"
%
clear all
clc
addpath('Prepared_data')
%% Devide clean data
% load clean data
filename='image_data.mat';
load(filename)% Load prepared data
Q=size(X,1);
% Divide clean data
trainRatio=0.9;
[trainInd,~,testInd] = divideint(Q,trainRatio,0,1-trainRatio);
xtr=X(trainInd,:)';% Training inputs
ytr=Y(trainInd)';% Training RUL
xts=X(testInd,:)';% Testing inputs
yts=Y(testInd)';% Testing targets
clearvars -except xtr ytr xts yts 
%% Divide adverserial data
% Load Untagreted Adverserial data
filename='image_data_ADV.mat';
load(filename)% Load prepared data
X1=X;
Y1=Y;
% Load Targeted Adverserial data
filename='image_data_Targeted_ADV.mat';
load(filename)% Load prepared data
X2=X;
Y2=Y;
% Define our inputs and Targtes
X=[X1; X2];
Y=[Y1; Y2];
clear X1 Y1 X2 Y2
% Divide adverserial data
Q=size(X,1);
trainRatio=0.9;
[trainInd,~,testInd] = divideint(Q,trainRatio,0,1-trainRatio);
xtr_ADV=X(trainInd,:)';% Training inputs
ytr_ADV=Y(trainInd)';% Training RUL
xts_ADV=X(testInd,:)';% Testing inputs
yts_ADV=Y(testInd)';% Testing targets
%% Provide data for training a robust network (both adverserial and clean)
xtr_ROB=[xtr_ADV,xtr];
ytr_ROB=[ytr_ADV,ytr];
%
clearvars -except xtr ytr xts yts xtr_ADV ytr_ADV xts_ADV yts_ADV xtr_ROB ytr_ROB
%
save('Prepared_data\\Divided_data.mat');


