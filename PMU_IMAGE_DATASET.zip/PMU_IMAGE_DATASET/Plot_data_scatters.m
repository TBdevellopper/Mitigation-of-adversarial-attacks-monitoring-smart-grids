clear
clc
addpath('Prepared_data','Data_processing_codes')
%% Clean Image dataset 
clear 
clc
%
variables_names={'Mean','Standard deviation','Skewness','Kurtosis','Peak to Peak', 'Square root of the arithmetic mean', ...
                 'Crest factor',' Shape factor','Impulse factor',...
                 'Margin factor','Energy'};
subplot(1,3,1)
load('image_data.mat')
idx_x=5;
idx_y=11;
noise_ratio=0.1;
Input1=addnoise(X(:,idx_x),noise_ratio); 
Input2=addnoise(X(:,idx_y),noise_ratio);
g=Y;
color = lines(length(unique(grp2idx(Y)))); % Generate color values
axe=gscatter(Input1,Input2,g,color(1:length(unique(grp2idx(Y))),:),'o*s',10,'on');
%
xlabel({variables_names{idx_x},'(a)'});
ylabel(variables_names{idx_y});
lgd= legend(axe);
lgd.EdgeColor='none';
lgd.Color='none';
%% Untargeted adverserial Image dataset 
clearvars -except idx_x idx_y variables_names noise_ratio
clc
subplot(1,3,2)
load('image_data_ADV.mat')
Input1=addnoise(X(:,idx_x),noise_ratio); 
Input2=addnoise(X(:,idx_y),noise_ratio);
g=Y;
color = lines(length(unique(grp2idx(Y)))); % Generate color values
axe=gscatter(Input1,Input2,g,color(1:length(unique(grp2idx(Y))),:),'o*s',10,'on');
%
xlabel({variables_names{idx_x},'(b)'});
ylabel(variables_names{idx_y});
lgd= legend(axe);
lgd.EdgeColor='none';
lgd.Color='none';
%% Targeted adverserial Image dataset 
clearvars -except idx_x idx_y variables_names noise_ratio
clc
subplot(1,3,3)
load('image_data_Targeted_ADV.mat')
CrestFactor=X(:,3); % 1 and 5,7,9 are the best [mean peak2peak CrestFactor ImpulseFactor];
Input2=X(:,4);
g=Y;
Input1=addnoise(X(:,idx_x),noise_ratio); 
Input2=addnoise(X(:,idx_y),noise_ratio);
g=Y;
color = lines(length(unique(grp2idx(Y)))); % Generate color values
axe=gscatter(Input1,Input2,g,color(1:length(unique(grp2idx(Y))),:),'o*s',10,'on');
%
xlabel({variables_names{idx_x},'(c)'});
ylabel(variables_names{idx_y});
lgd= legend(axe);
lgd.EdgeColor='none';
lgd.Color='none';