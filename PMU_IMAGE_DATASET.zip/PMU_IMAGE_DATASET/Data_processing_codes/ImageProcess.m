function [X,Y]=ImageProcess(foldername,listing)

for i=1:numel(listing)
i
filename=[foldername '\\' listing(i).name];
data=imread(filename);
data=data(:,:,1);
% Denoising
net    = denoisingNetwork('DnCNN');
X_temp = denoiseImage(data,net);
% Segmentation based clustering (This technique lets you create a segmented labeled image using a specific clustering algorithm. Using K-means clustering�based segmentation, imsegkmeans segments an image into K number of clusters.)
[L,~]  = imsegkmeans(X_temp,2);
X_temp = labeloverlay(X_temp,L);
% Extruct image features (HOG)
[featureVector] = extractHOGFeatures(X_temp);
X(i,:)= featureVector;
%% Targets preprocessing
Y(i,:) =foldername(end-2:end);
end

end