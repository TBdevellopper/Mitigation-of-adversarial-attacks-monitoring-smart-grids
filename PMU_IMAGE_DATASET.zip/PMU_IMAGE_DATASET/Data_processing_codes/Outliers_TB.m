function[X,Y]=Outliers_TB(X,Y)
[~,TF] = rmoutliers(X);
X(TF==1,:)=[];
Y(TF==1)=[];
end