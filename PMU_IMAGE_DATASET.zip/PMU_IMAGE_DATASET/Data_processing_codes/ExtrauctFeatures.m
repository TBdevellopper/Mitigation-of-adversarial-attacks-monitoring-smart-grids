function [X,Y]=ExtrauctFeatures(X,Y)
% %% 1) Dimentionality reduction
% X=double(X);
% coeff  = pca(X);
% clc
% size(coeff)
% numComponenets=ceil(size(X,1)/4);% Compression rate = 0.25;
% coeff  = coeff(:,1:numComponenets);
% X =(X*coeff)';
X=double(X);

%% 1) Feature extraction
for i=1:size(X,1)
% Time Domain Features
   v             = X(i,:);
   Mean          = mean(v);
   Std           = std(v);
   Skewness      = skewness(v);
   Kurtosis      = kurtosis(v);
   Peak2Peak     = peak2peak(v);
   RMS           = rms(v);
   CrestFactor   = max(v)/RMS;
   ShapeFactor   = RMS/mean(abs(v));
   ImpulseFactor = max(v)/mean(abs(v));
   MarginFactor  = max(v)/mean(abs(v))^2;
   Energy        = sum(v.^2);
% Collect features
   Xnew(i,:)=[ Mean,Std,Skewness,Kurtosis,Peak2Peak,RMS,CrestFactor,ShapeFactor,ImpulseFactor,...
           MarginFactor,Energy];
end
X=Xnew;
%% 2) Wavelet denoising;
for i=1:size(X,2)
%% 2-1 Sclalling & 2-2 Denoising
if mean(X(:,i))> 0
idx=isinf(X(:,i));
idx=find(idx==1);
X(idx,i)=missing;
X(:,i)=fillmissing(X(:,i),'previous');% Filling Inf values
X(:,i)=wdenoise(scaledata(X(:,i),0,1),1); % Sclalling & Denoising
end
end
%% 3) Resclaing
for i=1:size(X,2)
X(:,i)=scaledata(X(:,i),0,1); 
end
%% 4) Remove outlier
Y=categorical(cellstr(Y));
[X,Y]=Outliers_TB(X,Y);
 end