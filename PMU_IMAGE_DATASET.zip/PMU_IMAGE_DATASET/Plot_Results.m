clear all
clc
%%  1) Confusion matrices
figure(1)
addpath('Results')
load('results.mat');
classlabels=categorical({'FLT','GNL','SMS'});
% plot confusion
subplot(1,3,1)
confusionchart(Metrics_ts_Clean.Confusion,classlabels);
xlabel({'Predicted Class','(a)'});
% plot confusion
subplot(1,3,2)
confusionchart(Metrics_ts_ADV.Confusion,classlabels);
xlabel({'Predicted Class','(b)'});
% plot confusion
subplot(1,3,3)
confusionchart(Metrics_ts_ROB.Confusion,classlabels);
xlabel({'Predicted Class','(c)'});

%%  2) Adverserial data example
clear
clc
addpath('ADV_Data_codes');
%
foldername=('DB_FLT');
listing = dir([foldername '\\*.jpg']);
indexOfClass=1;
IndexOfImage=1;
filename=[foldername '\\' listing(IndexOfImage).name];
%
[XAdv,Perturbation]=Gnerate_Targeted_Adverserial_Examples(filename,indexOfClass);
figure(2)
subplot(1,3,1)
imagesc(imread(filename));
xlabel('(a)');
subplot(1,3,2)
imagesc(Perturbation);
xlabel('(b)');
subplot(1,3,3)
imagesc(XAdv);
xlabel('(c)');