%   same discription written in "A_Prepare_Clean_Data.m" except that the
%   files uploded from folders containing untargated adverserial data
%  "DB_FLT_Targeted_ADV","DB_GNL_Targeted_ADV", and
%  "DB_FLT_Targeted_ADV";
%   Prepared data will be stored in "Prepared_data" folder as "image_data_Targeted_ADV.mat"
%
%
clear
clc
addpath('Data_processing_codes')
%% 1) DB_FLT_ADV
foldername=('DB_FLT_Targeted_ADV');
listing = dir([foldername '\\*.jpg']);
[X,Y]=ImageProcess_ADV(foldername,listing);
[X1,Y1]=ExtrauctFeatures(X,Y);
clearvars -except X1 Y1 
%% 2) DB_GNL_ADV
foldername=('DB_GNL_Targeted_ADV');
listing = dir([foldername '\\*.jpg']);
[X,Y]=ImageProcess_ADV(foldername,listing);
[X2,Y2]=ExtrauctFeatures(X,Y);
clearvars -except X1 Y1 X2 Y2
%% 3) DB_SMS_ADV
foldername=('DB_SMS_Targeted_ADV');
listing = dir([foldername '\\*.jpg']);
[X,Y]=ImageProcess_ADV(foldername,listing);
[X3,Y3]=ExtrauctFeatures(X,Y);
clearvars -except X1 Y1 X2 Y2 X3 Y3
%% 4) Orgenize data
X=[X1; X2; X3];
Y=[Y1; Y2; Y3];
clearvars -except X Y
%% 5) SMOTE: Synthetic Minority Over-sampling Technique 
[X,Y]= SMOTE(X,Y); % SMOTE
%% 6) Sellection based on data vesualization
% 1 and 5,7,9 are the best [mean peak2peak CrestFactor ImpulseFactor];
% X=X(:,[1 5 7 9]);
%% 6) Save data
clearvars -except X Y
save('Prepared_data\\image_data_Targeted_ADV.mat')
