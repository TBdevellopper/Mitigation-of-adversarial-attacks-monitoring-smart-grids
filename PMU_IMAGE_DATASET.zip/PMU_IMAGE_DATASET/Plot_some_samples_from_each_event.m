clear all
clc
%% FLT
i=5;
foldername='DB_FLT';
listing = dir([foldername '\\*.jpg']);
filename=[foldername '\\' listing(i).name];
%
figure(1)
data=imread(filename);
%
subplot(1,3,1)
imagesc(data);
xlabel('(a)')
%% GNL
i=5;
foldername='DB_GNL';
listing = dir([foldername '\\*.jpg']);
filename=[foldername '\\' listing(i).name];
%
figure(1)
data=imread(filename);
%
subplot(1,3,2)
imagesc(data);
xlabel('(b)')
%% SMS
i=5;
foldername='DB_SMS';
listing = dir([foldername '\\*.jpg']);
filename=[foldername '\\' listing(i).name];
%
figure(1)
data=imread(filename);
%
subplot(1,3,3)
imagesc(data);
xlabel('(c)')

