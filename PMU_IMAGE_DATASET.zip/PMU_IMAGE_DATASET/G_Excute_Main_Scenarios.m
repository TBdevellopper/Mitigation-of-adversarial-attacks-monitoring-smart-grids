% These codes will provide final apllication reults which will be stored in
% "Results" folder as "results.mat"
%
clear all
clc
rng('default')
addpath('Prepared_data','Machine_Learning_functions')
%Devide data
% load clean data
load('Divided_data.mat');
%% First scenario: Train & Test LSTM Network on clean data
maxEpochs=500;
miniBatchSize = 20;
options = trainingOptions('adam', ...
    'MaxEpochs',maxEpochs, ...
    'MiniBatchSize',miniBatchSize, ...
    'InitialLearnRate',0.1, ...
    'GradientThreshold',1, ...
    'Shuffle','never', ...
    'L2Regularization',0.01,...
    'ExecutionEnvironment','cpu',...
    'Plots','training-progress',...
    'Verbose',0);
% Training & testing
[network]= LSTM_TB(xtr,ytr,xts,yts,options);
Metrics_ts_Clean=network.Metrics_ts;
net=network.net;
%
clearvars -except net Metrics_ts_Clean options xts_ADV yts_ADV xtr_ROB ytr_ROB
%% Second scenario: Test LSTM on adverserial data

% Test LSTM on adverserial data
yts_hat_ADV    = classify(net,xts_ADV);
Metrics_ts_ADV = Metrics_class(yts_ADV,yts_hat_ADV);
%
clearvars -except Metrics_ts_Clean Metrics_ts_ADV options xts_ADV yts_ADV xtr_ROB ytr_ROB

%% Third scenario: Train the nework to be robust on Adveserial data
% Training on both cleand and adverserial data & testing on adverserial
% data
[ROB_network]= LSTM_TB(xtr_ROB,ytr_ROB,xts_ADV,yts_ADV,options);
Metrics_ts_ROB=ROB_network.Metrics_ts;
net=ROB_network.net;
%
clearvars -except Metrics_ts_Clean Metrics_ts_ADV Metrics_ts_ROB net
%
% save('Results\\results.mat')


