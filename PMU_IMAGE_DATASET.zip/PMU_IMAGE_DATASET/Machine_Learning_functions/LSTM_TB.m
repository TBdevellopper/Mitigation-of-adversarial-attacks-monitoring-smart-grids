function [network]= LSTM_TB(xtr,ytr,xts,yts,options)
%% Build classifiction model with net network
%% Observations should be organized horizantally (Features,observations)
featureDimension=size(xtr,1);
numResponses= numel(unique(ytr));
%% Layers identification
numHiddenUnits = 20;
layers = [ ...
    sequenceInputLayer(featureDimension)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numResponses)
    softmaxLayer
    classificationLayer('Name','output')];
%% Training
[net,info] = trainNetwork(xtr,ytr,layers,options);
% Evaluate Training
ytr_hat =classify(net,xtr);
Metrics_tr= Metrics_class(ytr,ytr_hat);
%% Testing
yts_hat =classify(net,xts);
% Evaluate Testing
Metrics_ts= Metrics_class(yts,yts_hat);
%% Save results
network.net=net;                 % trained net
network.info=info;               % information about trained net
network.Metrics_tr=Metrics_tr;
network.Metrics_ts=Metrics_ts;
network.yts_hat=yts_hat;
end