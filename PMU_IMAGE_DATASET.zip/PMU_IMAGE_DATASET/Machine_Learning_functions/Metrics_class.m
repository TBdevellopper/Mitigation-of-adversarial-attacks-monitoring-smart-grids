function [Metrics]= Metrics_class(Y,Y_hat)
% Classification accuracy
Accuracy = (length(find(Y == Y_hat'')))/numel(Y);
% Confusin matrix features
C = confusionmat(Y,Y_hat);
cmt = C';
diagonal = diag(cmt);
% Precision
sum_of_rows = sum(cmt, 2);
precision = diagonal ./ sum_of_rows;
Precision = mean(precision);
% Recall
sum_of_columns = sum(cmt, 1);
recall = diagonal ./ sum_of_columns';
Recall= mean(recall);
% F1 score
F1 = 2*((Precision*Recall)/(Precision+Recall));
% AUC
% FPR = [Recall/Precision] * 2 * Recall
% [tpr,fpr]=roc(double(Y'),double(Y_hat));% False positive rate and trure positiverate
% AUC=trapz(fpr,tpr);
% Save
Metrics.Confusion=C;
Metrics.Accuracy=Accuracy;
Metrics.Recall=Recall;
Metrics.F1=F1;
Metrics.Precision=Precision ;
%Metrics.tpr=tpr;
%Metrics.fpr=fpr;
end